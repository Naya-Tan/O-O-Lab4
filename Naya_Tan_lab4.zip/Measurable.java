package Naya_Tan_Lab4;

public interface Measurable {
	
	// measures the shape using the area
	 double measure();

}
